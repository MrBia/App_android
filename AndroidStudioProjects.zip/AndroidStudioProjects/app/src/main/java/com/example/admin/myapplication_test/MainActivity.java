package com.example.admin.myapplication_test;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText textSend;
    TextView textReceive;
    Button btnSend;
    Button btnReceive;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textSend = (EditText) findViewById(R.id.id_textSend);
        textReceive = (TextView) findViewById(R.id.id_textReceive);
        btnSend = (Button) findViewById(R.id.id_btnSend);
        btnReceive = (Button) findViewById(R.id.id_btnReceive);
        final String textSend_S = textSend.getText().toString();
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textReceive.setText(textSend.getText());
            }
        });
    }
}
